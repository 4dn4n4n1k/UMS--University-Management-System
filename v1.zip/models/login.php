<?php
    require_once "database.php";

    function login($username, $password){
        $conn = dbConnect();

        if(!$conn){
            return null;
        }

        $sql = "SELECT * FROM users WHERE username = ? AND PASSWORD = ?";

        $stmt = mysqli_prepare($conn, $sql);

        mysqli_stmt_bind_param($stmt, "ss", $username, $password);
        mysqli_stmt_execute($stmt);

        $result = mysqli_stmt_get_result($stmt);

        if(mysqli_num_rows($result) > 0){
            
            $row = mysqli_fetch_assoc($result);

            mysqli_close($conn);
            return $row;
        }

        mysqli_stmt_close($stmt);
        mysqli_close($conn);

        return false;
    }

    if($_SERVER["REQUEST_METHOD"] == "POST"){

        $email = $_POST["email"];
        $password = $_POST["password"];
        $user = login($email, $password);

        if($user !== flase){
            header("Location: welcome.php");
            exit();
        }
        else{
            header("Location: sign_in.php");
            exit();
        }
    }
?>