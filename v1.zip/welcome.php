<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
</head>

<body>

    <h1>Welcome!</h1>
    <p>Login successful.</p>

</body>
</html>